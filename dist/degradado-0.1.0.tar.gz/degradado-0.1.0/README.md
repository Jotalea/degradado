# degradado
Simple Python module for printing text using gradients
